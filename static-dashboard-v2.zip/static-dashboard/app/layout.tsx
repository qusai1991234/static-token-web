import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "STATIC Protocol Dashboard",
  description: "Real-time dashboard for STATIC token on Solana",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet"/>
      </head>
      <body style={{ margin: 0, background: "#050508" }}>{children}</body>
    </html>
  );
}
