import { NextRequest, NextResponse } from "next/server";
import { PublicKey } from "@solana/web3.js";
import {
  getConnection,
  getUserStatePDA,
  calcTax,
  decodeUserState,
} from "@/lib/solana";

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get("address");

  if (!address) {
    return NextResponse.json({ error: "Missing address" }, { status: 400 });
  }

  try {
    const wallet     = new PublicKey(address);
    const connection = getConnection();
    const userPDA    = getUserStatePDA(wallet);

    const accountInfo = await connection.getAccountInfo(userPDA);

    if (!accountInfo) {
      return NextResponse.json({
        found:      false,
        idleHours:  0,
        taxPct:     2,
        volume24h:  0,
        lastAction: null,
        message:    "Wallet not initialized — no transfers yet",
      });
    }

    const state = decodeUserState(accountInfo.data);
    if (!state) {
      return NextResponse.json({ error: "Failed to decode state" }, { status: 500 });
    }

    const now        = Math.floor(Date.now() / 1000);
    const idleHours  = Math.max(0, (now - state.lastActionTs) / 3600);
    const taxPct     = calcTax(idleHours);

    return NextResponse.json({
      found:      true,
      owner:      state.owner.toBase58(),
      idleHours:  parseFloat(idleHours.toFixed(2)),
      taxPct:     parseFloat(taxPct.toFixed(2)),
      volume24h:  state.volume24h,
      lastAction: new Date(state.lastActionTs * 1000).toISOString(),
      lastReset:  new Date(state.lastResetTs * 1000).toISOString(),
    });

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
