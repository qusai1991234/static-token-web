import { NextResponse } from "next/server";
import {
  getConnection,
  getRewardPoolPDA,
  decodeRewardPool,
  PROGRAM_ID,
  getUserStatePDA,
  decodeUserState,
} from "@/lib/solana";
import { PublicKey } from "@solana/web3.js";

export async function GET() {
  try {
    const connection = getConnection();
    const poolPDA    = getRewardPoolPDA();

    // ── Reward Pool ──
    const poolInfo = await connection.getAccountInfo(poolPDA);
    let pool = null;

    if (poolInfo) {
      pool = decodeRewardPool(poolInfo.data);
    }

    // ── Top Wallets (all UserState accounts) ──
    const accounts = await connection.getProgramAccounts(PROGRAM_ID, {
      filters: [{ dataSize: 64 }], // UserState size
    });

    const now = Math.floor(Date.now() / 1000);
    const WINDOW = 86400;

    const activeWallets = accounts
      .map(({ pubkey, account }) => {
        const state = decodeUserState(account.data);
        if (!state) return null;
        const idle = now - state.lastActionTs;
        return {
          wallet:    state.owner.toBase58(),
          volume24h: state.volume24h,
          idleHours: parseFloat((idle / 3600).toFixed(1)),
          active:    idle < WINDOW && state.volume24h > 0,
        };
      })
      .filter(Boolean)
      .filter((w: any) => w.active)
      .sort((a: any, b: any) => b.volume24h - a.volume24h)
      .slice(0, 100);

    const totalVolume = activeWallets.reduce((s: number, w: any) => s + w.volume24h, 0);

    const leaderboard = activeWallets.map((w: any) => ({
      ...w,
      share: totalVolume > 0
        ? parseFloat(((w.volume24h / totalVolume) * 100).toFixed(2))
        : 0,
      estimatedReward: pool && totalVolume > 0
        ? Math.floor(pool.totalAccumulated * w.volume24h / totalVolume)
        : 0,
    }));

    return NextResponse.json({
      pool: pool ? {
        totalAccumulated:  pool.totalAccumulated,
        lastDistribution:  new Date(pool.lastDistribution * 1000).toISOString(),
        nextDistribution:  new Date((pool.lastDistribution + 86400) * 1000).toISOString(),
        isPaused:          pool.isPaused,
        authority:         pool.authority.toBase58(),
        secondsUntilNext:  Math.max(0, (pool.lastDistribution + 86400) - now),
      } : null,
      leaderboard,
      totalActiveWallets: leaderboard.length,
      totalVolume24h:     totalVolume,
    });

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
