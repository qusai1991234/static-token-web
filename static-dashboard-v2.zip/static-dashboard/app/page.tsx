"use client";
import { useState, useEffect, useRef } from "react";

const PROGRAM_ID = "DLPdn9uzMW9rKvsppE5n4SDRtjqRukgFcQofP5YrkLBE";

function calcTax(h: number) {
  return Math.min(200 + Math.floor(h) * 20, 2500) / 100;
}

type WalletData = {
  found: boolean;
  idleHours?: number;
  taxPct?: number;
  volume24h?: number;
  lastAction?: string;
  error?: string;
};

type PoolData = {
  pool?: {
    totalAccumulated: number;
    lastDistribution: string;
    nextDistribution: string;
    secondsUntilNext: number;
    isPaused: boolean;
  };
  leaderboard?: Array<{
    wallet: string;
    volume24h: number;
    share: number;
    estimatedReward: number;
    idleHours: number;
  }>;
  totalActiveWallets?: number;
  totalVolume24h?: number;
};

export default function Dashboard() {
  const [walletAddr, setWalletAddr] = useState("EUyLvjqbzMHG4px55CiuFBDLrM8sKxxgHBLtrtZfWgMe");
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [poolData, setPoolData]     = useState<PoolData | null>(null);
  const [loading, setLoading]       = useState(false);
  const [simAmount, setSimAmount]   = useState(1000);
  const [sliderIdle, setSliderIdle] = useState(0);
  const [liveIdle, setLiveIdle]     = useState(0);
  const [cd, setCd]                 = useState({ h: 23, m: 59, s: 59 });
  const [lastUpdate, setLastUpdate] = useState("—");
  const idleInterval                = useRef<any>(null);

  // ── Fetch pool on mount + every 30s ──
  useEffect(() => {
    fetchPool();
    const t = setInterval(fetchPool, 30000);
    return () => clearInterval(t);
  }, []);

  // ── Live idle counter ──
  useEffect(() => {
    if (!walletData?.lastAction) return;
    clearInterval(idleInterval.current);
    idleInterval.current = setInterval(() => {
      const secs = (Date.now() - new Date(walletData.lastAction!).getTime()) / 1000;
      setLiveIdle(secs / 3600);
    }, 1000);
    return () => clearInterval(idleInterval.current);
  }, [walletData]);

  // ── Countdown from pool ──
  useEffect(() => {
    if (!poolData?.pool) return;
    const nextTs = new Date(poolData.pool.nextDistribution).getTime();
    const t = setInterval(() => {
      const rem = Math.max(0, nextTs - Date.now());
      setCd({
        h: Math.floor(rem / 3600000),
        m: Math.floor((rem % 3600000) / 60000),
        s: Math.floor((rem % 60000) / 1000),
      });
    }, 1000);
    return () => clearInterval(t);
  }, [poolData]);

  async function fetchPool() {
    try {
      const res  = await fetch("/api/pool");
      const data = await res.json();
      setPoolData(data);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch {}
  }

  async function loadWallet() {
    if (!walletAddr.trim()) return;
    setLoading(true);
    try {
      const res  = await fetch(`/api/wallet?address=${walletAddr.trim()}`);
      const data = await res.json();
      setWalletData(data);
      setLiveIdle(data.idleHours || 0);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch (e: any) {
      setWalletData({ found: false, error: e.message });
    } finally {
      setLoading(false);
    }
  }

  // ── Computed ──
  const idle      = sliderIdle > 0 ? sliderIdle : liveIdle;
  const tax       = calcTax(idle);
  const taxColor  = tax > 15 ? "#f85149" : tax > 8 ? "#d29922" : "#3fb950";
  const gaugeOff  = 188 * (1 - tax / 25);
  const simTotal  = simAmount * tax / 100;
  const simBase   = simAmount * 0.02;
  const simExtra  = Math.max(0, simTotal - simBase);
  const pool      = poolData?.pool;
  const lb        = poolData?.leaderboard || [];
  const secondsLeft = pool?.secondsUntilNext ?? 86400;
  const cyclePct  = Math.min(100, ((86400 - secondsLeft) / 86400) * 100);
  const myReward  = pool && poolData?.totalVolume24h
    ? Math.floor(pool.totalAccumulated * (walletData?.volume24h || 0) / Math.max(1, poolData.totalVolume24h))
    : null;

  const pad = (n: number) => String(n).padStart(2, "0");

  // ── Styles ──
  const S: any = {
    body:       { margin:0, background:"#080b10", color:"#c9d1d9", fontFamily:"'Outfit',sans-serif", fontSize:14, minHeight:"100vh", display:"flex", overflowX:"hidden" },
    sidebar:    { width:220, flexShrink:0, background:"#0d1117", borderRight:"1px solid rgba(255,255,255,0.06)", display:"flex", flexDirection:"column", position:"fixed" as const, top:0, bottom:0, left:0, zIndex:50 },
    logoWrap:   { padding:"24px 20px 20px", borderBottom:"1px solid rgba(255,255,255,0.06)" },
    logo:       { fontFamily:"'JetBrains Mono',monospace", fontSize:16, fontWeight:600, color:"#f0f6fc", display:"flex", alignItems:"center", gap:8 },
    logoDot:    { width:8, height:8, background:"#58a6ff", borderRadius:"50%", boxShadow:"0 0 12px #58a6ff", flexShrink:0, animation:"breathe 3s ease-in-out infinite" },
    logoSub:    { fontSize:10, color:"#6e7681", letterSpacing:"0.1em", textTransform:"uppercase" as const, marginTop:4 },
    nav:        { padding:"16px 10px", flex:1, display:"flex", flexDirection:"column" as const, gap:2 },
    navLabel:   { fontSize:10, letterSpacing:"0.1em", color:"#6e7681", textTransform:"uppercase" as const, padding:"8px 10px 6px", fontWeight:600 },
    navItem:    (active: boolean) => ({ display:"flex", alignItems:"center", gap:10, padding:"8px 10px", borderRadius:6, fontSize:13, color: active ? "#58a6ff" : "#8b949e", background: active ? "rgba(88,166,255,0.12)" : "transparent", fontWeight: active ? 500 : 400, cursor:"pointer", textDecoration:"none" }),
    sideBot:    { padding:16, borderTop:"1px solid rgba(255,255,255,0.06)" },
    netBadge:   { display:"flex", alignItems:"center", gap:8, padding:"8px 10px", background:"#161e28", border:"1px solid rgba(255,255,255,0.06)", borderRadius:6, fontFamily:"'JetBrains Mono',monospace", fontSize:11 },
    netDot:     { width:6, height:6, background:"#3fb950", borderRadius:"50%", boxShadow:"0 0 6px #3fb950", flexShrink:0, animation:"breathe 2s ease-in-out infinite" },
    content:    { marginLeft:220, flex:1, display:"flex", flexDirection:"column" as const, minWidth:0 },
    topbar:     { height:52, borderBottom:"1px solid rgba(255,255,255,0.06)", display:"flex", alignItems:"center", padding:"0 28px", gap:12, position:"sticky" as const, top:0, background:"rgba(8,11,16,0.9)", backdropFilter:"blur(12px)", zIndex:40 },
    searchWrap: { flex:1, maxWidth:520, position:"relative" as const },
    searchInput:{ width:"100%", background:"#161e28", border:"1px solid rgba(255,255,255,0.06)", color:"#f0f6fc", fontFamily:"'JetBrains Mono',monospace", fontSize:12, padding:"7px 12px 7px 34px", borderRadius:6, outline:"none" },
    btn:        { height:32, padding:"0 16px", background:"#58a6ff", color:"#080b10", border:"none", borderRadius:6, fontFamily:"'Outfit',sans-serif", fontSize:12, fontWeight:600, cursor:"pointer" },
    page:       { padding:"24px 28px", flex:1 },
    kpiStrip:   { display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:1, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:8, overflow:"hidden", marginBottom:20 },
    kpi:        { background:"#0d1117", padding:"16px 20px" },
    kpiLabel:   { fontSize:11, fontWeight:500, color:"#6e7681", letterSpacing:"0.05em", textTransform:"uppercase" as const, marginBottom:8 },
    kpiVal:     { fontFamily:"'JetBrains Mono',monospace", fontSize:22, fontWeight:600, color:"#f0f6fc", lineHeight:1, marginBottom:4 },
    kpiMeta:    { fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#6e7681" },
    mainGrid:   { display:"grid", gridTemplateColumns:"1fr 1fr 330px", gap:16, marginBottom:16 },
    sideStack:  { display:"flex", flexDirection:"column" as const, gap:16 },
    card:       { background:"#0d1117", border:"1px solid rgba(255,255,255,0.06)", borderRadius:8, overflow:"hidden" },
    cardHead:   { padding:"14px 18px", borderBottom:"1px solid rgba(255,255,255,0.06)", display:"flex", alignItems:"center", justifyContent:"space-between" },
    cardTitle:  { fontSize:12, fontWeight:600, color:"#8b949e", letterSpacing:"0.04em" },
    cardBody:   { padding:18 },
    tag:        (color: string) => ({ fontFamily:"'JetBrains Mono',monospace", fontSize:10, padding:"2px 7px", borderRadius:4, fontWeight:500, ...tagColors[color] }),
    row:        { display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:"1px solid rgba(255,255,255,0.04)", fontSize:12 },
    dk:         { color:"#8b949e" },
    dv:         (c?: string) => ({ fontFamily:"'JetBrains Mono',monospace", fontSize:12, fontWeight:500, color: c || "#f0f6fc" }),
    prog:       { marginBottom:12 },
    progTop:    { display:"flex", justifyContent:"space-between", fontSize:11, color:"#6e7681", marginBottom:5, fontFamily:"'JetBrains Mono',monospace" },
    progTrack:  { height:4, background:"#161e28", borderRadius:99, overflow:"hidden" },
    countdown:  { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:16 },
    cdUnit:     { background:"#161e28", border:"1px solid rgba(255,255,255,0.06)", borderRadius:6, padding:"10px 6px", textAlign:"center" as const },
    cdNum:      { fontFamily:"'JetBrains Mono',monospace", fontSize:20, fontWeight:600, color:"#58a6ff", display:"block", lineHeight:1, marginBottom:3 },
    cdLbl:      { fontSize:9, color:"#6e7681", textTransform:"uppercase" as const, letterSpacing:"0.08em" },
    simInput:   { width:"100%", background:"#161e28", border:"1px solid rgba(255,255,255,0.06)", color:"#f0f6fc", fontFamily:"'JetBrains Mono',monospace", fontSize:13, padding:"8px 12px", borderRadius:6, outline:"none", marginBottom:12 },
    secCheck:   { display:"inline-flex", alignItems:"center", gap:5, fontSize:11, fontFamily:"'JetBrains Mono',monospace", padding:"2px 8px", borderRadius:4, background:"rgba(63,185,80,0.1)", color:"#3fb950", border:"1px solid rgba(63,185,80,0.2)" },
    div:        { height:1, background:"rgba(255,255,255,0.06)", margin:"14px 0" },
    footer:     { padding:"16px 28px", borderTop:"1px solid rgba(255,255,255,0.06)", display:"flex", justifyContent:"space-between", fontSize:11, color:"#6e7681", fontFamily:"'JetBrains Mono',monospace" },
  };

  const tagColors: any = {
    blue:   { background:"rgba(88,166,255,0.12)",  color:"#58a6ff",  border:"1px solid rgba(88,166,255,0.2)" },
    green:  { background:"rgba(63,185,80,0.12)",   color:"#3fb950",  border:"1px solid rgba(63,185,80,0.2)" },
    red:    { background:"rgba(248,81,73,0.12)",   color:"#f85149",  border:"1px solid rgba(248,81,73,0.2)" },
    orange: { background:"rgba(210,153,34,0.12)",  color:"#d29922",  border:"1px solid rgba(210,153,34,0.2)" },
    muted:  { background:"#161e28",                color:"#6e7681",  border:"1px solid rgba(255,255,255,0.06)" },
  };

  const decayPts = [0,5,10,15,24,48,115];
  const rankCls  = ["r1","r2","r3"];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap');
        @keyframes breathe { 0%,100%{opacity:1;box-shadow:0 0 8px currentColor} 50%{opacity:0.6;box-shadow:0 0 20px currentColor} }
        * { box-sizing:border-box; margin:0; padding:0; }
        input:focus { border-color:rgba(88,166,255,0.5)!important; box-shadow:0 0 0 3px rgba(88,166,255,0.08)!important; }
        input[type=range] { width:100%;appearance:none;height:4px;background:#161e28;border-radius:99px;outline:none;cursor:pointer; }
        input[type=range]::-webkit-slider-thumb { appearance:none;width:14px;height:14px;background:#58a6ff;border-radius:50%;box-shadow:0 0 8px rgba(88,166,255,0.4);cursor:pointer; }
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:#080b10} ::-webkit-scrollbar-thumb{background:#161e28;border-radius:2px}
        table { width:100%;border-collapse:collapse;font-size:12px; }
        thead th { padding:10px 16px;text-align:left;font-size:10px;font-weight:600;color:#6e7681;letter-spacing:0.08em;text-transform:uppercase;border-bottom:1px solid rgba(255,255,255,0.06);background:#111820;white-space:nowrap;font-family:'Outfit',sans-serif; }
        tbody td { padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.04);font-family:'JetBrains Mono',monospace;font-size:11.5px;color:#c9d1d9;white-space:nowrap; }
        tbody tr:hover td { background:rgba(255,255,255,0.02); }
        tbody tr:last-child td { border-bottom:none; }
        .rank-badge { display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:4px;font-size:11px;font-weight:700; }
        .r1{background:rgba(210,153,34,0.15);color:#f0c040} .r2{background:rgba(139,148,158,0.15);color:#8b949e} .r3{background:rgba(145,80,78,0.2);color:#c07060} .rn{background:#161e28;color:#6e7681}
        .mini-bar{width:60px;height:3px;background:#161e28;border-radius:99px;overflow:hidden;flex-shrink:0}
        .mini-fill{height:100%;background:#58a6ff;border-radius:99px}
      `}</style>

      <div style={S.body}>

        {/* Sidebar */}
        <aside style={S.sidebar}>
          <div style={S.logoWrap}>
            <div style={S.logo}>
              <div style={S.logoDot}/>
              STATIC
            </div>
            <div style={S.logoSub}>Protocol Analytics</div>
          </div>
          <nav style={S.nav}>
            <div style={S.navLabel}>Dashboard</div>
            {[["◈","Overview",true],["⬡","Tax Engine",false],["◎","Rewards",false],["≡","Leaderboard",false]].map(([icon,label,active]) => (
              <a key={label as string} style={S.navItem(active as boolean)}><span style={{fontSize:14,width:16,textAlign:"center"}}>{icon}</span>{label}</a>
            ))}
            <div style={{...S.navLabel,marginTop:8}}>Tools</div>
            {[["⊕","Simulator",false],["◷","History",false]].map(([icon,label,active]) => (
              <a key={label as string} style={S.navItem(active as boolean)}><span style={{fontSize:14,width:16,textAlign:"center"}}>{icon}</span>{label}</a>
            ))}
          </nav>
          <div style={S.sideBot}>
            <div style={S.netBadge}>
              <div style={S.netDot}/>
              <div>
                <div style={{color:"#f0f6fc",fontSize:11,fontWeight:500}}>{process.env.NEXT_PUBLIC_NETWORK?.toUpperCase() || "DEVNET"}</div>
                <div style={{color:"#6e7681",fontSize:10}}>Solana RPC · Live</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Content */}
        <div style={S.content}>

          {/* Topbar */}
          <div style={S.topbar}>
            <div style={S.searchWrap}>
              <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:"#6e7681",fontSize:13,pointerEvents:"none"}}>⌕</span>
              <input style={S.searchInput}
                value={walletAddr}
                onChange={e => setWalletAddr(e.target.value)}
                onKeyDown={e => e.key === "Enter" && loadWallet()}
                placeholder="Search wallet address..."/>
            </div>
            <button style={S.btn} onClick={loadWallet} disabled={loading}>
              {loading ? "Loading..." : "Analyze"}
            </button>
            <div style={{marginLeft:"auto",fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:"#6e7681"}}>
              Updated {lastUpdate}
            </div>
          </div>

          {/* Page */}
          <div style={S.page}>

            {/* KPI Strip */}
            <div style={S.kpiStrip}>
              {[
                { label:"Tax Rate",        val: tax.toFixed(2)+"%",         meta: tax<=2?"Base rate · Active":`+${(tax-2).toFixed(1)}% idle penalty`, metaColor: tax>15?"#f85149":tax>8?"#d29922":"#6e7681" },
                { label:"Idle Time",       val: liveIdle.toFixed(1)+"h",    meta: liveIdle<1?"No penalty":`${liveIdle.toFixed(0)}h without activity`, metaColor: liveIdle>15?"#f85149":liveIdle>8?"#d29922":"#6e7681" },
                { label:"Reward Pool",     val: pool?(pool.totalAccumulated/1e9).toFixed(2):"—", meta:"Accumulated tokens", metaColor:"#58a6ff" },
                { label:"Active Wallets",  val: poolData?.totalActiveWallets?.toString()||"—", meta:"Last 24 hours", metaColor:"#6e7681" },
                { label:"Next Distribution", val:`${pad(cd.h)}:${pad(cd.m)}`, meta:"Until distribution", metaColor:"#6e7681" },
              ].map(k => (
                <div key={k.label} style={S.kpi}>
                  <div style={S.kpiLabel}>{k.label}</div>
                  <div style={S.kpiVal}>{k.val}</div>
                  <div style={{...S.kpiMeta,color:k.metaColor}}>{k.meta}</div>
                </div>
              ))}
            </div>

            {/* Main Grid */}
            <div style={S.mainGrid}>

              {/* Tax Engine */}
              <div style={S.card}>
                <div style={S.cardHead}>
                  <span style={S.cardTitle}>Tax Engine</span>
                  <span style={S.tag("blue")}>LIVE</span>
                </div>
                <div style={S.cardBody}>
                  <div style={{display:"flex",alignItems:"center",gap:24,marginBottom:20}}>
                    <svg width="140" height="80" viewBox="0 0 140 80" overflow="visible" style={{flexShrink:0}}>
                      <defs>
                        <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#3fb950"/>
                          <stop offset="50%" stopColor="#d29922"/>
                          <stop offset="100%" stopColor="#f85149"/>
                        </linearGradient>
                      </defs>
                      <path fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={9} strokeLinecap="round" d="M 14 74 A 60 60 0 0 1 126 74"/>
                      <path fill="none" stroke="url(#g)" strokeWidth={9} strokeLinecap="round"
                        strokeDasharray={188} strokeDashoffset={gaugeOff}
                        style={{transition:"stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)",filter:`drop-shadow(0 0 6px ${taxColor}60)`}}
                        d="M 14 74 A 60 60 0 0 1 126 74"/>
                      <text fontFamily="'JetBrains Mono'" fontSize={20} fontWeight={600} fill="#f0f6fc" textAnchor="middle" x={70} y={68}>{tax.toFixed(1)}%</text>
                    </svg>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:34,fontWeight:600,color:taxColor,lineHeight:1,marginBottom:4}}>{tax.toFixed(2)}%</div>
                      <div style={{fontSize:12,color:"#8b949e",marginBottom:10}}>{tax<=2?"Base rate — no penalty":tax<=8?"Mild idle penalty":tax<=15?"High idle penalty":"Maximum tax"}</div>
                      <div style={{display:"flex",gap:6}}>
                        <span style={S.tag("green")}>▾ Burn</span>
                        <span style={S.tag("blue")}>Pool →</span>
                      </div>
                    </div>
                  </div>

                  {[
                    ["Base Tax",       "2.00%",  "#3fb950"],
                    ["Idle Penalty",   `+${Math.min(idle*0.2,23).toFixed(2)}%`, idle>0?"#f85149":"#8b949e"],
                    ["Burned (base)",  "2.00%",  "#f85149"],
                    ["Extra Burn",     `${Math.max(0,(tax-2)/2).toFixed(2)}%`, "#f85149"],
                    ["To Reward Pool", `${Math.max(0,(tax-2)/2).toFixed(2)}%`, "#58a6ff"],
                  ].map(([k,v,c]) => (
                    <div key={k} style={S.row}>
                      <span style={S.dk}>{k}</span>
                      <span style={S.dv(c)}>{v}</span>
                    </div>
                  ))}

                  <div style={S.div}/>
                  <div style={{fontSize:11,color:"#6e7681",marginBottom:8,fontWeight:500,letterSpacing:"0.04em",textTransform:"uppercase"}}>Decay Schedule</div>
                  {decayPts.map(h => {
                    const t = calcTax(h);
                    const c = t>15?"#f85149":t>8?"#d29922":"#3fb950";
                    return <div key={h} style={{...S.row,borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                      <span style={S.dk}>{h}h idle</span>
                      <span style={S.dv(c)}>{t.toFixed(1)}%</span>
                    </div>;
                  })}
                </div>
              </div>

              {/* Simulator */}
              <div style={S.card}>
                <div style={S.cardHead}>
                  <span style={S.cardTitle}>Transfer Simulator</span>
                  <span style={S.tag("muted")}>INTERACTIVE</span>
                </div>
                <div style={S.cardBody}>
                  <div style={{fontSize:11,color:"#6e7681",marginBottom:6}}>Transfer Amount</div>
                  <input style={S.simInput} type="number" value={simAmount}
                    onChange={e => setSimAmount(parseFloat(e.target.value)||0)}/>

                  {[
                    ["Tax Rate",          tax.toFixed(2)+"%",               taxColor],
                    ["Total Deducted",    simTotal.toFixed(4),               "#f85149"],
                    ["Burned",            (simBase+simExtra/2).toFixed(4),   "#f85149"],
                    ["To Reward Pool",    (simExtra/2).toFixed(4),           "#58a6ff"],
                    ["Receiver Gets",     (simAmount-simTotal).toFixed(4),   "#3fb950"],
                  ].map(([k,v,c]) => (
                    <div key={k} style={S.row}><span style={S.dk}>{k}</span><span style={S.dv(c)}>{v}</span></div>
                  ))}

                  <div style={S.div}/>
                  <div style={{fontSize:11,color:"#6e7681",marginBottom:8,fontWeight:500,letterSpacing:"0.04em",textTransform:"uppercase"}}>Idle Time Simulation</div>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:"#6e7681",marginBottom:6,fontFamily:"'JetBrains Mono',monospace"}}>
                    <span>Simulate wallet idle time</span>
                    <span style={{color:"#58a6ff"}}>{sliderIdle}h</span>
                  </div>
                  <input type="range" min={0} max={115} step={1} value={sliderIdle}
                    onChange={e => setSliderIdle(parseFloat(e.target.value))}/>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#6e7681",fontFamily:"'JetBrains Mono',monospace",marginTop:4}}>
                    <span>0h · 2%</span><span>48h · 21.8%</span><span>115h · 25%</span>
                  </div>

                  <div style={S.div}/>
                  <div style={{fontSize:11,color:"#6e7681",marginBottom:8,fontWeight:500,letterSpacing:"0.04em",textTransform:"uppercase"}}>Whitelist (0% Tax)</div>
                  {["Dev Wallet","Raydium Auth V4","Raydium AMM V4","Raydium CLMM"].map(name => (
                    <div key={name} style={S.row}>
                      <span style={S.dk}>{name}</span>
                      <span style={S.secCheck}>✓ Exempt</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Side */}
              <div style={S.sideStack}>

                {/* Distribution */}
                <div style={S.card}>
                  <div style={S.cardHead}>
                    <span style={S.cardTitle}>Distribution</span>
                    <span style={S.tag("blue")}>24H CYCLE</span>
                  </div>
                  <div style={S.cardBody}>
                    <div style={S.countdown}>
                      {[{n:cd.h,l:"hrs"},{n:cd.m,l:"min"},{n:cd.s,l:"sec"},{n:poolData?.totalActiveWallets||0,l:"recip"}].map(({n,l}) => (
                        <div key={l} style={S.cdUnit}>
                          <span style={S.cdNum}>{pad(n as number)}</span>
                          <span style={S.cdLbl}>{l}</span>
                        </div>
                      ))}
                    </div>

                    <div style={S.prog}>
                      <div style={S.progTop}><span>Cycle progress</span><span>{cyclePct.toFixed(0)}%</span></div>
                      <div style={S.progTrack}>
                        <div style={{height:"100%",width:`${cyclePct}%`,background:cyclePct>90?"#f85149":cyclePct>70?"#d29922":"#58a6ff",borderRadius:99,transition:"width 0.8s ease"}}/>
                      </div>
                    </div>

                    {[
                      ["Pool Balance",  pool ? (pool.totalAccumulated/1e9).toFixed(4)+" tokens" : "—", "#58a6ff"],
                      ["Est. Reward",   myReward !== null ? myReward.toLocaleString()+" tokens" : "—", "#3fb950"],
                      ["Max Recipients","100", "#f0f6fc"],
                      ["Status",        pool?.isPaused ? "⏸ Paused" : "▶ Running", pool?.isPaused ? "#f85149" : "#3fb950"],
                    ].map(([k,v,c]) => (
                      <div key={k} style={S.row}><span style={S.dk}>{k}</span><span style={S.dv(c)}>{v}</span></div>
                    ))}
                  </div>
                </div>

                {/* Security */}
                <div style={S.card}>
                  <div style={S.cardHead}>
                    <span style={S.cardTitle}>Security</span>
                    <span style={S.tag("green")}>9 / 10</span>
                  </div>
                  <div style={S.cardBody}>
                    {["24h Distribution Lock","ATA Validation","Dev-Only Dist.","Recipient Check","Pause Switch"].map(item => (
                      <div key={item} style={S.row}>
                        <span style={S.dk}>{item}</span>
                        <span style={S.secCheck}>✓</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>

            {/* Leaderboard */}
            <div style={S.card}>
              <div style={S.cardHead}>
                <span style={S.cardTitle}>Leaderboard — Top 24h Volume</span>
                <span style={S.tag("muted")}>{lb.length || "—"} wallets</span>
              </div>
              <div style={{overflowX:"auto"}}>
                <table>
                  <thead>
                    <tr><th>#</th><th>Wallet</th><th>24h Volume</th><th>Est. Reward</th><th>Pool Share</th><th>Idle</th></tr>
                  </thead>
                  <tbody>
                    {lb.length === 0 ? (
                      <tr><td colSpan={6} style={{textAlign:"center",color:"#6e7681",padding:"2rem",fontFamily:"'Outfit',sans-serif"}}>
                        {loading ? "Loading from chain..." : "Click Analyze to load real data from Solana"}
                      </td></tr>
                    ) : lb.map((w, i) => {
                      const barW = lb[0]?.volume24h ? (w.volume24h / lb[0].volume24h * 100).toFixed(0) : "0";
                      const idleColor = w.idleHours > 15 ? "#f85149" : w.idleHours > 8 ? "#d29922" : "#6e7681";
                      return (
                        <tr key={w.wallet}>
                          <td><span className={`rank-badge ${rankCls[i]||"rn"}`}>{i+1}</span></td>
                          <td style={{color:"#c9d1d9"}}>{w.wallet.slice(0,4)}...{w.wallet.slice(-4)}</td>
                          <td>
                            <div style={{display:"flex",alignItems:"center",gap:8}}>
                              <div className="mini-bar"><div className="mini-fill" style={{width:`${barW}%`}}/></div>
                              {(w.volume24h/1e9).toFixed(4)}
                            </div>
                          </td>
                          <td style={{color:"#3fb950"}}>{(w.estimatedReward/1e9).toFixed(4)}</td>
                          <td style={{color:"#6e7681"}}>{w.share}%</td>
                          <td style={{color:idleColor}}>{w.idleHours.toFixed(1)}h</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          <div style={S.footer}>
            <span>STATIC Protocol · Token-2022 · Solana · © 2026</span>
            <span style={{color:"#58a6ff",opacity:0.5,fontSize:10}}>{PROGRAM_ID}</span>
          </div>

        </div>
      </div>
    </>
  );
}
