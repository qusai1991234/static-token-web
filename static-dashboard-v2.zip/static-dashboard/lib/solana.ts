import { Connection, PublicKey } from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";

// ================================================================
// CONFIG
// ================================================================
export const PROGRAM_ID    = new PublicKey("DLPdn9uzMW9rKvsppE5n4SDRtjqRukgFcQofP5YrkLBE");
export const REWARD_WALLET = new PublicKey("5orXkk6aQZf4ssCagCPDDQB7CtFyKUpcdGUYqtufUzBM");
export const DEV_WALLET    = new PublicKey("EUyLvjqbzMHG4px55CiuFBDLrM8sKxxgHBLtrtZfWgMe");
export const NETWORK       = process.env.NEXT_PUBLIC_NETWORK || "devnet";

export const RPC_URL = NETWORK === "mainnet-beta"
  ? "https://api.mainnet-beta.solana.com"
  : "https://api.devnet.solana.com";

export function getConnection() {
  return new Connection(RPC_URL, "confirmed");
}

// ================================================================
// PDAs
// ================================================================
export function getUserStatePDA(wallet: PublicKey) {
  const [pda] = PublicKey.findProgramAddressSync(
    [Buffer.from("user-state-v2"), wallet.toBuffer()],
    PROGRAM_ID
  );
  return pda;
}

export function getRewardPoolPDA() {
  const [pda] = PublicKey.findProgramAddressSync(
    [Buffer.from("reward-pool-v2")],
    PROGRAM_ID
  );
  return pda;
}

// ================================================================
// TAX CALC
// ================================================================
export function calcTax(idleHours: number) {
  const bps = Math.min(200 + Math.floor(idleHours) * 20, 2500);
  return bps / 100;
}

export function calcBreakdown(taxPct: number, amount: number) {
  const total   = amount * taxPct / 100;
  const baseTax = amount * 0.02;
  const extra   = Math.max(0, total - baseTax);
  return {
    total,
    received:  amount - total,
    burnBase:  baseTax,
    burnExtra: extra / 2,
    reward:    extra / 2,
  };
}

// ================================================================
// DECODE ACCOUNT DATA (manual — no IDL dependency)
// ================================================================
export function decodeUserState(data: Buffer) {
  // discriminator (8) + owner (32) + last_action_ts (8) + volume_24h (8) + last_reset_ts (8)
  if (data.length < 64) return null;
  const owner         = new PublicKey(data.slice(8, 40));
  const lastActionTs  = Number(data.readBigInt64LE(40));
  const volume24h     = Number(data.readBigUInt64LE(48));
  const lastResetTs   = Number(data.readBigInt64LE(56));
  return { owner, lastActionTs, volume24h, lastResetTs };
}

export function decodeRewardPool(data: Buffer) {
  // discriminator (8) + total_accumulated (8) + last_distribution (8) + authority (32) + is_paused (1)
  if (data.length < 57) return null;
  const totalAccumulated = Number(data.readBigUInt64LE(8));
  const lastDistribution = Number(data.readBigInt64LE(16));
  const authority        = new PublicKey(data.slice(24, 56));
  const isPaused         = data[56] === 1;
  return { totalAccumulated, lastDistribution, authority, isPaused };
}
